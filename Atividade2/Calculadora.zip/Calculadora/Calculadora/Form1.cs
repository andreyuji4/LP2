﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        double num1, num2, resultado;

        private void btnleave_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnclear_Click(object sender, EventArgs e)
        {

        }

        private void txtnum2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtnum2.Text, out num2))
            {
                MessageBox.Show("Numero 2 inválido!");
                txtnum2.Focus();
            }
        }

        private void btnsub_Click(object sender, EventArgs e)
        {
            resultado = num1 - num2;
            txtnum3.Text = resultado.ToString();
        }

        private void btnmult_Click(object sender, EventArgs e)
        {
            resultado = num1 * num2;
            txtnum3.Text = resultado.ToString();
        }

        private void btndiv_Click(object sender, EventArgs e)
        {
            if (num2 == 0)
            {
                MessageBox.Show("Não pode dividir por zero!!!!!","ERRO",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            resultado = num1 / num2;
            txtnum3.Text = resultado.ToString();
        }

        private void btnclear_Click_1(object sender, EventArgs e)
        {
            txtnum1.Clear();
            txtnum2.Clear();
            txtnum3.Clear();
        }

        private void txtnum1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtnum1.Text, out num1))
            {
                MessageBox.Show("Numero 1 inválido!");
                txtnum1.Focus();
            }
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            resultado = num1 + num2;
            txtnum3.Text = resultado.ToString();
        }
    }
}
