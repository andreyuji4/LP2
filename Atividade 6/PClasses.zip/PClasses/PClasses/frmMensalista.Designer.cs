﻿namespace PClasses
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.txtSalario = new System.Windows.Forms.TextBox();
            this.txtData = new System.Windows.Forms.TextBox();
            this.lblMat = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSlrMensal = new System.Windows.Forms.Label();
            this.lblData = new System.Windows.Forms.Label();
            this.btnInstMen = new System.Windows.Forms.Button();
            this.btnInstMenPar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(110, 95);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(233, 20);
            this.txtNome.TabIndex = 0;
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(137, 55);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(79, 20);
            this.txtMatricula.TabIndex = 1;
            // 
            // txtSalario
            // 
            this.txtSalario.Location = new System.Drawing.Point(137, 135);
            this.txtSalario.Name = "txtSalario";
            this.txtSalario.Size = new System.Drawing.Size(100, 20);
            this.txtSalario.TabIndex = 2;
            // 
            // txtData
            // 
            this.txtData.Location = new System.Drawing.Point(175, 168);
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(100, 20);
            this.txtData.TabIndex = 3;
            // 
            // lblMat
            // 
            this.lblMat.AutoSize = true;
            this.lblMat.Location = new System.Drawing.Point(40, 62);
            this.lblMat.Name = "lblMat";
            this.lblMat.Size = new System.Drawing.Size(52, 13);
            this.lblMat.TabIndex = 4;
            this.lblMat.Text = "Matrícula";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(40, 102);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(35, 13);
            this.lblNome.TabIndex = 5;
            this.lblNome.Text = "Nome";
            // 
            // lblSlrMensal
            // 
            this.lblSlrMensal.AutoSize = true;
            this.lblSlrMensal.Location = new System.Drawing.Point(40, 138);
            this.lblSlrMensal.Name = "lblSlrMensal";
            this.lblSlrMensal.Size = new System.Drawing.Size(76, 13);
            this.lblSlrMensal.TabIndex = 6;
            this.lblSlrMensal.Text = "Salário Mensal";
            // 
            // lblData
            // 
            this.lblData.AutoSize = true;
            this.lblData.Location = new System.Drawing.Point(40, 175);
            this.lblData.Name = "lblData";
            this.lblData.Size = new System.Drawing.Size(129, 13);
            this.lblData.TabIndex = 7;
            this.lblData.Text = "Data Entrada na Empresa";
            // 
            // btnInstMen
            // 
            this.btnInstMen.Location = new System.Drawing.Point(32, 262);
            this.btnInstMen.Name = "btnInstMen";
            this.btnInstMen.Size = new System.Drawing.Size(205, 77);
            this.btnInstMen.TabIndex = 8;
            this.btnInstMen.Text = "Instanciar Mensalista";
            this.btnInstMen.UseVisualStyleBackColor = true;
            this.btnInstMen.Click += new System.EventHandler(this.btnInstMen_Click);
            // 
            // btnInstMenPar
            // 
            this.btnInstMenPar.Location = new System.Drawing.Point(262, 262);
            this.btnInstMenPar.Name = "btnInstMenPar";
            this.btnInstMenPar.Size = new System.Drawing.Size(205, 77);
            this.btnInstMenPar.TabIndex = 9;
            this.btnInstMenPar.Text = "Instanciar Mensalista passando parâmetros";
            this.btnInstMenPar.UseVisualStyleBackColor = true;
            this.btnInstMenPar.Click += new System.EventHandler(this.btnInstMenPar_Click);
            // 
            // frmMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(493, 386);
            this.Controls.Add(this.btnInstMenPar);
            this.Controls.Add(this.btnInstMen);
            this.Controls.Add(this.lblData);
            this.Controls.Add(this.lblSlrMensal);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMat);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.txtSalario);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.txtNome);
            this.Name = "frmMensalista";
            this.Text = "frmMensalista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.TextBox txtSalario;
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.Label lblMat;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSlrMensal;
        private System.Windows.Forms.Label lblData;
        private System.Windows.Forms.Button btnInstMen;
        private System.Windows.Forms.Button btnInstMenPar;
    }
}