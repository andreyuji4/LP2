﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Linq.Expressions;


namespace PDisaster0030482321020
{
    internal class Cidade
    {
        public int IdCidade { get; set; }
        public string Nome { get; set; }
        public string Uf { get; set; }
        public int  Populacao { get; set; }
        public DataTable listar()
        {
            SqlDataAdapter daCidade;
            DataTable dtCidade = new DataTable();

            try
            {
                daCidade = new SqlDataAdapter("SELECT * FROM Cidade ORDER BY NOME", frmPrincipal.conexao);
                daCidade.Fill(dtCidade);
                daCidade.FillSchema(dtCidade, SchemaType.Source);
            }

            catch (Exception)
            {
                throw;
            }
            return dtCidade;
        }
        public int Incluir() // INCLUSAO
        {
            int retorno = 0;

            try
            {
                SqlCommand mycommand;

                mycommand = new SqlCommand("INSERT INTO Cidades VALUES (@NOME, @UF, @POPULACAO)", frmPrincipal.conexao);

                mycommand.Parameters.Add(new SqlParameter("@NOME", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@UF", SqlDbType.Char));
                mycommand.Parameters.Add(new SqlParameter("@POPULACAO", SqlDbType.Int));

                mycommand.Parameters["@NOME"].Value = Nome;
                mycommand.Parameters["@UF"].Value = Uf;
                mycommand.Parameters["@POPULACAO"].Value = Populacao;

                retorno = mycommand.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }

            return retorno;
        }
    }
}
