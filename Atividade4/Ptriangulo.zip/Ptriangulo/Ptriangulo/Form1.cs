﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        double valA, valB, valC;

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtVal1.Clear();
            txtVal2.Clear();
            txtVal3.Clear();
        }

        private void btnVerify_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtVal1.Text == "" || txtVal2.Text == "" || txtVal3.Text == "")
                {
                    MessageBox.Show("Burro!! Digite um valor");
                }
                else
                {
                    valA = double.Parse(txtVal1.Text);
                    valB = double.Parse(txtVal2.Text);
                    valC = double.Parse(txtVal3.Text);

                    if (valA + valB < valC ||
                        valB + valC < valA ||
                        valC + valA < valB)
                    {
                        MessageBox.Show("A soma de dois lados deve ser maior que o terceiro!");
                    }
                    else if (valA != valB && valB != valC && valC != valA) 
                    {
                        MessageBox.Show("Escaleno");
                    }
                    else if (valA == valB && valB == valC)
                    {
                        MessageBox.Show("Equilatero");
                    }
                    else if (valA == valB && valB != valC || 
                        valA == valB && valA != valC || 
                        valA == valC && valC != valB || 
                        valA == valC && valA != valB ||
                        valB == valC && valC != valA ||
                        valB == valC && valB != valA)
                    {
                        MessageBox.Show("Isósceles");
                    }
                }
            }
            catch
            {
                MessageBox.Show("Digite Números!!");
            }
        }
    }
}
