﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos2
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        double SalBruto, Salario, Grato;
        int Producao;
        string Nome, Matricula, Sal, Grat, Prod;

        private void btnCalc_Click(object sender, EventArgs e)
        {
            Nome = txtboxNome.Text;
            Matricula = txtboxMat.Text;
            Sal = mskboxSal.Text;
            Grat = mskboxGrat.Text; 
            Prod = txtboxProducao.Text;

            if (string.IsNullOrEmpty(Nome) || string.IsNullOrEmpty(Matricula) || string.IsNullOrEmpty(Sal) || string.IsNullOrEmpty(Grat) || string.IsNullOrEmpty(Prod))
            {
                MessageBox.Show("Preencha todos os campos requeridos!");
            }

            else
            {
                try
                {
                    Salario = double.Parse(mskboxSal.Text);
                    Producao = int.Parse(txtboxProducao.Text);
                    Grato = double.Parse(mskboxGrat.Text);

                    if (Producao >= 150)
                    {
                        SalBruto = Grato + Salario + (Salario * ((0.05 + 0.1 + 0.1)));
                    }

                    else if (Producao >= 120)
                    {
                        SalBruto = Grato + Salario + (Salario * ((0.05 + 0.1)));
                    }

                    else if (Producao >= 100)
                    {
                        SalBruto = Grato + Salario + (Salario * 0.05);
                    }

                    else if (Producao < 100)
                    {
                        SalBruto = Salario;
                    }

                    if (SalBruto > 7000)
                    {
                        if (Producao < 150 || Grato <= 0)
                            SalBruto = 7000;

                        else
                        {

                        }
                    }

                    lblSal.Text = SalBruto.ToString();
                }
                catch (Exception)
                {
                    MessageBox.Show("Nos campos: Salário, Produção e Gratificação, insira apenas números!");
                } 
            }
        }
    }
}
