﻿namespace PTesteMetodos2
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtboxNome = new System.Windows.Forms.TextBox();
            this.txtboxMat = new System.Windows.Forms.TextBox();
            this.txtboxProducao = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblSal = new System.Windows.Forms.Label();
            this.btnCalc = new System.Windows.Forms.Button();
            this.mskboxSal = new System.Windows.Forms.MaskedTextBox();
            this.mskboxGrat = new System.Windows.Forms.MaskedTextBox();
            this.SuspendLayout();
            // 
            // txtboxNome
            // 
            this.txtboxNome.Location = new System.Drawing.Point(215, 106);
            this.txtboxNome.Name = "txtboxNome";
            this.txtboxNome.Size = new System.Drawing.Size(212, 20);
            this.txtboxNome.TabIndex = 0;
            // 
            // txtboxMat
            // 
            this.txtboxMat.Location = new System.Drawing.Point(215, 151);
            this.txtboxMat.Name = "txtboxMat";
            this.txtboxMat.Size = new System.Drawing.Size(100, 20);
            this.txtboxMat.TabIndex = 1;
            // 
            // txtboxProducao
            // 
            this.txtboxProducao.Location = new System.Drawing.Point(215, 197);
            this.txtboxProducao.Name = "txtboxProducao";
            this.txtboxProducao.Size = new System.Drawing.Size(100, 20);
            this.txtboxProducao.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(137, 107);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 15);
            this.label1.TabIndex = 5;
            this.label1.Text = "Nome ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(137, 151);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 15);
            this.label2.TabIndex = 6;
            this.label2.Text = "Matrícula";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(137, 198);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 15);
            this.label3.TabIndex = 7;
            this.label3.Text = "Produção";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(137, 246);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 15);
            this.label4.TabIndex = 8;
            this.label4.Text = "Salário";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(137, 292);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 15);
            this.label5.TabIndex = 9;
            this.label5.Text = "Gratificação";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(440, 215);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 16);
            this.label6.TabIndex = 10;
            this.label6.Text = "Salário Bruto";
            // 
            // lblSal
            // 
            this.lblSal.AutoSize = true;
            this.lblSal.Location = new System.Drawing.Point(569, 217);
            this.lblSal.Name = "lblSal";
            this.lblSal.Size = new System.Drawing.Size(35, 13);
            this.lblSal.TabIndex = 11;
            this.lblSal.Text = "label7";
            // 
            // btnCalc
            // 
            this.btnCalc.Location = new System.Drawing.Point(429, 246);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(104, 34);
            this.btnCalc.TabIndex = 12;
            this.btnCalc.Text = "CALCULAR";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // mskboxSal
            // 
            this.mskboxSal.Location = new System.Drawing.Point(215, 246);
            this.mskboxSal.Mask = "00000.00";
            this.mskboxSal.Name = "mskboxSal";
            this.mskboxSal.Size = new System.Drawing.Size(128, 20);
            this.mskboxSal.TabIndex = 13;
            // 
            // mskboxGrat
            // 
            this.mskboxGrat.Location = new System.Drawing.Point(215, 291);
            this.mskboxGrat.Mask = "00000.00";
            this.mskboxGrat.Name = "mskboxGrat";
            this.mskboxGrat.Size = new System.Drawing.Size(100, 20);
            this.mskboxGrat.TabIndex = 14;
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.mskboxGrat);
            this.Controls.Add(this.mskboxSal);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.lblSal);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtboxProducao);
            this.Controls.Add(this.txtboxMat);
            this.Controls.Add(this.txtboxNome);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtboxNome;
        private System.Windows.Forms.TextBox txtboxMat;
        private System.Windows.Forms.TextBox txtboxProducao;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblSal;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.MaskedTextBox mskboxSal;
        private System.Windows.Forms.MaskedTextBox mskboxGrat;
    }
}