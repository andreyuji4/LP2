﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos2
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int EspacoBranco, cont;
            char[] vetor = rchtxt1.Text.ToCharArray();

            EspacoBranco = 0;
            cont = 0;

            while (cont < vetor.Length)
            {
                if (char.IsWhiteSpace(vetor[cont]))
                {
                    EspacoBranco++;
                }

                cont++;
            }

            if (EspacoBranco > 0)
            {
                MessageBox.Show("A quantidade de espaços em branco é:  " + (EspacoBranco));
            }

            else
                MessageBox.Show("Não há espaços em branco no texto");
        }

        private void btnR_Click(object sender, EventArgs e)
        {
            int LetraR;
            char[] vetor = rchtxt1.Text.ToCharArray();

            LetraR = 0;

            foreach (char c in vetor) 
            {
                if (c == 'R' || c == 'r')
                { 
                    LetraR++;   
                }
            }

            if (LetraR > 0)
            {
                MessageBox.Show("O número de letras R presentes no texto é:  " + LetraR);
            }

            else
                MessageBox.Show("Não há nenhuma letra 'R' no texto");
        }

        private void btnPar_Click(object sender, EventArgs e)
        {
            int Pares, cont;
            char[] vetor = rchtxt1.Text.ToCharArray();

            Pares = 0;

            for (cont = 1; cont < vetor.Length; cont++)
            {
                if (rchtxt1.Text[cont] == rchtxt1.Text[cont - 1])
                {
                    Pares++;
                }
            }

            if (Pares > 0)
                MessageBox.Show("O número de pares presentes no texto é:  " + Pares);
                

            else
                MessageBox.Show("Não há pares presentes no texto");
        }
    }
}
