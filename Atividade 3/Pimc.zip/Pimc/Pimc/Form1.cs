﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Double CalcularIMC(double peso, double altura)
        {
            return Math.Round(peso / (altura * altura), 1);
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            try
            {
                double peso = Convert.ToDouble(txtPeso.Text);
                double altura = Convert.ToDouble(txtAltura.Text);

                if ((peso <= 0) || (altura <= 0))
                    MessageBox.Show("Somente Valores Acima de 0");
                else
                {

                    double imc = CalcularIMC(peso, altura);

                    imc = Math.Round(imc, 1);
                    txtImc.Text = imc.ToString();

                    if (imc < 18.5)

                        MessageBox.Show("Magreza");

                    else if (imc < 24.9)

                        MessageBox.Show("Normal");

                    else if (imc < 29.9)


                        MessageBox.Show("Sobrepeso");

                    else if (imc < 39.9)

                        MessageBox.Show("Obesidade");

                    else

                        MessageBox.Show("Obesidade Grave");
                }
            }
            catch ( Exception ex )
            {
                MessageBox.Show("Valores Inválidos");
            }

        }

        private void btnLeave_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnClean_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtPeso.Clear();
            txtImc.Clear();
        }
    }
}
