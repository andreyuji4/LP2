﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVendas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string[,] vendas = new string[4, 4];
            double auxiliar,soma =0,somafinal =0;

            for (int i = 0; i < vendas.GetLength(0); i++)
            {
                for (int j = 0; j < vendas.GetLength(1); j++)
                {
                    vendas[i, j] = Interaction.InputBox($"Insira o total vendido no mês {i + 1} na semana {j + 1}");
                    if (!double.TryParse(vendas[i, j], out auxiliar))
                    {     
                        MessageBox.Show("Número inválido");
                        j--;
                    }
                    else
                    {
                        if (auxiliar < 0)
                        { 
                            MessageBox.Show("Valor deve ser maior ou igual a 0");
                            j--;
                        }
                        else
                        {
                            lstbxVendas.Items.Add($"Total do mês  {i + 1} Semana {j + 1}: {auxiliar.ToString("c2")}");
                            soma += auxiliar;
                            somafinal += auxiliar;
                        }
                    }
                }
                lstbxVendas.Items.Add($">> Total Mês R$ {soma.ToString("c2")}");
                lstbxVendas.Items.Add("-------------------------------------");
                soma = 0;
            }
            lstbxVendas.Items.Add($">> Total Geral: {somafinal.ToString("c2")}");


            
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxVendas.Items.Clear();
        }
    }
}
